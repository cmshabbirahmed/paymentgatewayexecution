package com.marshsoftwaregeeks.javaknowledge.controller;

import com.marshsoftwaregeeks.javaknowledge.model.ProductRequest;
import com.marshsoftwaregeeks.javaknowledge.model.StripeResponse;
import com.marshsoftwaregeeks.javaknowledge.service.StripeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/product/v1")
public class ProductCheckOutController {

    public ProductCheckOutController(StripeService stripeService) {
        this.stripeService = stripeService;
    }

    private StripeService stripeService;



    @PostMapping("/checkout")
    public ResponseEntity<StripeResponse> checkoutProducts(@RequestBody ProductRequest productRequest) {
        StripeResponse stripeResponse = stripeService.checkoutProducts(productRequest);
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(stripeResponse);
    }
}
