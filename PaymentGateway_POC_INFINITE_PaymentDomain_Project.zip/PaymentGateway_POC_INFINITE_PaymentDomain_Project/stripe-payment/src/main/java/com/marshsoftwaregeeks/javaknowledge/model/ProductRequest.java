package com.marshsoftwaregeeks.javaknowledge.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductRequest {

    private Long amount;
    private Long quantity;
    private String name;
    private String currency;
}
