package com.marshsoftwaregeeks.javaknowledge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripePaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
